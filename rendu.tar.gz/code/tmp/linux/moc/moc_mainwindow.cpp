/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../../QtrainSim/src/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[33];
    char stringdata0[411];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 11), // "commandSent"
QT_MOC_LITERAL(2, 23, 0), // ""
QT_MOC_LITERAL(3, 24, 7), // "command"
QT_MOC_LITERAL(4, 32, 35), // "on_actionCharger_Maquette_tri..."
QT_MOC_LITERAL(5, 68, 17), // "selectionMaquette"
QT_MOC_LITERAL(6, 86, 8), // "maquette"
QT_MOC_LITERAL(7, 95, 7), // "addLoco"
QT_MOC_LITERAL(8, 103, 7), // "no_loco"
QT_MOC_LITERAL(9, 111, 10), // "closeEvent"
QT_MOC_LITERAL(10, 122, 12), // "QCloseEvent*"
QT_MOC_LITERAL(11, 135, 5), // "event"
QT_MOC_LITERAL(12, 141, 16), // "toggleSimulation"
QT_MOC_LITERAL(13, 158, 13), // "emergencyStop"
QT_MOC_LITERAL(14, 172, 14), // "simulationStep"
QT_MOC_LITERAL(15, 187, 17), // "finishedAnimation"
QT_MOC_LITERAL(16, 205, 6), // "zoomIn"
QT_MOC_LITERAL(17, 212, 7), // "zoomOut"
QT_MOC_LITERAL(18, 220, 7), // "zoomFit"
QT_MOC_LITERAL(19, 228, 10), // "rotatePlus"
QT_MOC_LITERAL(20, 239, 11), // "rotateMinus"
QT_MOC_LITERAL(21, 251, 17), // "viewContactNumber"
QT_MOC_LITERAL(22, 269, 20), // "viewAiguillageNumber"
QT_MOC_LITERAL(23, 290, 11), // "viewLocoLog"
QT_MOC_LITERAL(24, 302, 10), // "toggleLoco"
QT_MOC_LITERAL(25, 313, 9), // "locoCtrls"
QT_MOC_LITERAL(26, 323, 13), // "toggleInertie"
QT_MOC_LITERAL(27, 337, 15), // "afficherMessage"
QT_MOC_LITERAL(28, 353, 7), // "message"
QT_MOC_LITERAL(29, 361, 19), // "afficherMessageLoco"
QT_MOC_LITERAL(30, 381, 7), // "numLoco"
QT_MOC_LITERAL(31, 389, 5), // "print"
QT_MOC_LITERAL(32, 395, 15) // "onReturnPressed"

    },
    "MainWindow\0commandSent\0\0command\0"
    "on_actionCharger_Maquette_triggered\0"
    "selectionMaquette\0maquette\0addLoco\0"
    "no_loco\0closeEvent\0QCloseEvent*\0event\0"
    "toggleSimulation\0emergencyStop\0"
    "simulationStep\0finishedAnimation\0"
    "zoomIn\0zoomOut\0zoomFit\0rotatePlus\0"
    "rotateMinus\0viewContactNumber\0"
    "viewAiguillageNumber\0viewLocoLog\0"
    "toggleLoco\0locoCtrls\0toggleInertie\0"
    "afficherMessage\0message\0afficherMessageLoco\0"
    "numLoco\0print\0onReturnPressed"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      23,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  129,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       4,    0,  132,    2, 0x08 /* Private */,
       5,    1,  133,    2, 0x0a /* Public */,
       7,    1,  136,    2, 0x0a /* Public */,
       9,    1,  139,    2, 0x0a /* Public */,
      12,    0,  142,    2, 0x0a /* Public */,
      13,    0,  143,    2, 0x0a /* Public */,
      14,    0,  144,    2, 0x0a /* Public */,
      15,    0,  145,    2, 0x0a /* Public */,
      16,    0,  146,    2, 0x0a /* Public */,
      17,    0,  147,    2, 0x0a /* Public */,
      18,    0,  148,    2, 0x0a /* Public */,
      19,    0,  149,    2, 0x0a /* Public */,
      20,    0,  150,    2, 0x0a /* Public */,
      21,    0,  151,    2, 0x0a /* Public */,
      22,    0,  152,    2, 0x0a /* Public */,
      23,    0,  153,    2, 0x0a /* Public */,
      24,    1,  154,    2, 0x0a /* Public */,
      26,    0,  157,    2, 0x0a /* Public */,
      27,    1,  158,    2, 0x0a /* Public */,
      29,    2,  161,    2, 0x0a /* Public */,
      31,    0,  166,    2, 0x0a /* Public */,
      32,    0,  167,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    3,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    6,
    QMetaType::Void, QMetaType::Int,    8,
    QMetaType::Void, 0x80000000 | 10,   11,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QObjectStar,   25,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   28,
    QMetaType::Void, QMetaType::Int, QMetaType::QString,   30,   28,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->commandSent((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 1: _t->on_actionCharger_Maquette_triggered(); break;
        case 2: _t->selectionMaquette((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 3: _t->addLoco((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 4: _t->closeEvent((*reinterpret_cast< QCloseEvent*(*)>(_a[1]))); break;
        case 5: _t->toggleSimulation(); break;
        case 6: _t->emergencyStop(); break;
        case 7: _t->simulationStep(); break;
        case 8: _t->finishedAnimation(); break;
        case 9: _t->zoomIn(); break;
        case 10: _t->zoomOut(); break;
        case 11: _t->zoomFit(); break;
        case 12: _t->rotatePlus(); break;
        case 13: _t->rotateMinus(); break;
        case 14: _t->viewContactNumber(); break;
        case 15: _t->viewAiguillageNumber(); break;
        case 16: _t->viewLocoLog(); break;
        case 17: _t->toggleLoco((*reinterpret_cast< QObject*(*)>(_a[1]))); break;
        case 18: _t->toggleInertie(); break;
        case 19: _t->afficherMessage((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 20: _t->afficherMessageLoco((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 21: _t->print(); break;
        case 22: _t->onReturnPressed(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (MainWindow::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::commandSent)) {
                *result = 0;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 23)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 23;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 23)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 23;
    }
    return _id;
}

// SIGNAL 0
void MainWindow::commandSent(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
